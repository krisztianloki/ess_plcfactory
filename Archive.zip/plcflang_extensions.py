# user-defined functions for PLCFlang

def foo(x):
    return x * x * x


# add whatever you need here: