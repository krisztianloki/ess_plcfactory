# PLC Factory #

PLC Factory is intended to simplify programming PLCs by automatically generating template files.