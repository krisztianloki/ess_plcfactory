# PLC Factory #

PLC Factory is intended to simplify programming PLCs by automatically generating template files.


example of an invocation:
python plcfactory.py --device LNS-LEBT-010:Vac-PLC-11111 --template 4



TODO:

- (?) implement named variables, e.g. counters, in PLCF_Lang

- clean up repository (will be done at the end)

- code cleanup

- extend documentation